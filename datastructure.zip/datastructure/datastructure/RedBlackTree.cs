﻿using System;

namespace Codingriver
{
   public class RedBlackTree<T> where T : IComparable
    {
        public enum Color
        {
            Red,
            Black
        }
        public class Node<K> where K: T
        {
            public K data;
            public Node<K> parent;
            public Node<K> lc;
            public Node<K> rc;
            /// <summary>
            /// 高度
            /// </summary>
            public int height;
            public Color color;
            public Node(K data):this(data,null,null,null,0,Color.Red){}
            public Node(K data,Node<K> p, Node<K> l=null, Node<K> r=null,int h=0,Color c= Color.Red)
            {
                this.data = data;
                parent = p;
                this.lc = l;
                this.rc = r;
                this.height = h;
                this.color = c;
            }

        }

        private Node<T> _root;
        private  Node<T> _hot; // "命中"节点的父节点
        private int _size;

        public Node<T> Insert(T e)
        {
            Node<T> x = Search(e); if (x!=null) return x; //确认目标不存在（留意对_hot的设置）
            x = new Node<T>(e, _hot, null, null, -1); //创建红节点x：以_hot为父，黑高度-1
            _size++; //更新全树规模
            Node<T> xOld = x; SolveDoubleRed(x); return xOld; //经双红修正后，即可返回
        }//无论e是否存在于原树中，返回时总有x.data == e

        public bool Remove(T data)
        {
            return true;
        }

        public Node<T> Search(T data)
        {
            return searchIn(_root, data, _hot = null);
        }

        /// <summary>
        /// * RedBlack双红调整算法：解决节点x与其父均为红色的问题。分为两大类情况：
        ///*    RR-1：2次颜色翻转，2次黑高度更新，1~2次旋转，不再递归
        ///*    RR-2：3次颜色翻转，3次黑高度更新，0次旋转，需要递归
        /// </summary>
        /// <param name="x">x当前必为红</param>
        private void SolveDoubleRed(Node<T> x)
        {
            if (IsRoot(x)) //若已（递归）转至树根，则将其转黑，整树黑高度也随之递增
            { _root.color = Color.Black; _root.height++; return; } //否则，x的父亲p必存在
            Node<T> p = x.parent; if (IsBlack(p)) return; //若p为黑，则可终止调整。否则
            Node<T> g = p.parent; //既然p为红，则x的祖父必存在，且必为黑色
            Node<T> u = uncle(x); //以下，视x叔父u的颜色分别处理
            if (IsBlack(u))
            { //u为黑色（含NULL）时 //*DSA*/printf("  case RR-1:\n");
                if (IsLChild(x) == IsLChild(p)) //若x与p同侧（即zIg-zIg或zAg-zAg），则
                    p.color = Color.Black; //p由红转黑，x保持红
                else //若x与p异侧（即zIg-zAg或zAg-zIg），则
                    x.color = Color.Black; //x由红转黑，p保持红
                g.color = Color.Red; //g必定由黑转红
                                   ///// 以上虽保证总共两次染色，但因增加了判断而得不偿失
                                   ///// 在旋转后将根置黑、孩子置红，虽需三次染色但效率更高
                Node<T> gg = g.parent; //曾祖父（great-grand parent）
                Node<T> r = FromParentTo(g) = rotateAt(x); //调整后的子树根节点
                r.parent = gg; //与原曾祖父联接
            }
            else
            { //若u为红色 //*DSA*/printf("  case RR-2:\n");
                p.color = Color.Black; p.height++; //p由红转黑
                u.color = Color.Black; u.height++; //u由红转黑
                if (!IsRoot(g)) g.color = Color.Red; //g若非根，则转红
                SolveDoubleRed(g); //继续调整g（类似于尾递归，可优化为迭代形式）
            }
        }

        private void SolveDoubleBlack(Node<T> node)
        {

        }

        /// <summary>
        /// 按照 “3 + 4” 结构，联结3个节点及四个子树
        /// </summary>
        /// <returns></returns>
        private Node<T> Connect34(Node<T> a, Node<T> b, Node<T> c, Node<T> T0, Node<T> T1, Node<T> T2, Node<T> T3) 
        {
            a.lc = T0; if (T0!=null) T0.parent = a;
            a.rc = T1; if (T1 != null) T1.parent = a; updateHeight(a);
            c.lc = T2; if (T2 != null) T2.parent = c;
            c.rc = T3; if (T3 != null) T3.parent = c; updateHeight(c);
            b.lc = a; a.parent = b;
            b.rc = c; c.parent = b; updateHeight(b);
            return b; //该子树新的根节点
        }

        private Node<T> rotateAt(Node<T> node)
        {
            return null;
        }

        /// <summary>
        /// 更新节点高度
        /// 因统一定义Stature(NULL) = -1，故height比黑高度少一，好在不致影响到各种算法中的比较判断
        /// </summary>
        /// <param name="node"></param>
        /// <returns></returns>
        private int updateHeight(Node<T> node)
        {
            node.height = Max(Stature(node.lc), Stature(node.rc)); //孩子一般黑高度相等，除非出现双黑
            /*DSA*/// 红黑树中各节点左、右孩子的黑高度通常相等
            /*DSA*/// 这里之所以取更大值，是便于在删除节点后的平衡调整过程中，正确更新被删除节点父亲的黑高度
            /*DSA*/// 否则，rotateAt()会根据被删除节点的替代者（高度小一）设置父节点的黑高度
            return IsBlack(node) ? node.height++ : node.height; //若当前节点为黑，则计入黑深度
        }
        private bool IsRoot(Node<T>node)
        {
            //return node == _root;
            return node.parent == null;
        }
        private bool IsLChild(Node<T> node)
        {
            return !IsRoot(node) && node == node.parent.lc;
        }
        private bool IsRChild(Node<T> node)
        {
            return !IsRoot(node) && node == node.parent.rc;
        }
        private Node<T>uncle(Node<T> node)
        {
            return IsLChild(node.parent) ? node.parent.parent.rc : node.parent.parent.lc;
        }
        private Node<T> sibling(Node<T>node)
        {
            return IsLChild(node) ? node.parent.rc : node.parent.lc;
        }
        private Node<T> FromParentTo(Node<T> node)
        {
            return IsRoot(node)?_root:( IsLChild(node) ? node.parent.lc : node.parent.rc);
        }
        

        private bool IsBlack(Node<T> node)
        {
            return node==null || node.color == Color.Black;
        }

        /// <summary>
        /// 获取高度
        /// 因统一定义Stature(NULL) = -1，故height比黑高度少一，好在不致影响到各种算法中的比较判断
        /// </summary>
        /// <param name="node"></param>
        /// <returns></returns>
        private int Stature(Node<T> node)
        {
            return node != null ? node.height : -1;
        }
        private int Max(int a,int b)
        {
            return a >= b ? a : b;
        }
        private bool Equal(T data,Node<T> node)
        {
            return node == null || data.CompareTo(node.data)==0;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="v"></param>
        /// <param name="e"></param>
        /// <param name="hot"></param>
        /// <returns></returns>
        private Node<T> searchIn(Node<T> v, T e,Node<T> hot)
        {
            if (Equal(e, v)) return v; hot = v; //退化情况：在子树根节点v处命中
            while (true)
            { //一般地，反复不断地
                Node<T> c = (e.CompareTo( hot.data)<0) ? hot.lc : hot.rc; //确定深入方向
                if (Equal(e, c)) return c; hot = c; //命中返回，或者深入一层
            } //hot始终指向最后一个失败节点
        }//返回时，返回值指向命中节点（或假想的通配哨兵），hot指向其父亲（退化时为初始值NULL）

    }
}
